namespace belt_exam.Models
{
    public abstract class BaseEntity {}
}